# partial derivatives and their inverse of some copulas from the copula package
# new defined copulas store their partial derivative separately

setGeneric("dduCopula", function(u, copula, ...) standardGeneric("dduCopula"))
setGeneric("ddvCopula", function(u, copula, ...) standardGeneric("ddvCopula"))

## inverse partial derivatives 
# numerical standard function
invdduCopula <- function(u, copula, y) {
    if (length(u) != length(y)) 
        stop("Length of u and y differ!")
    warning("Numerical evaluation of invddu takes place.")
    res <- NULL
    for (i in 1:length(u)) {
        res <- rbind(res, optimize( function(x) 
          (dduCopula(cbind(rep(u[i], length(x)), x),copula) - y[i])^2, 
            interval = c(0, 1))$minimum)
    }
    return(res)
}

setGeneric("invdduCopula")

invddvCopula <- function(v, copula, y) {
    if (length(v) != length(y)) 
        stop("Length of v and y differ!")
  warning("Numerical evaluation of invddv takes place.")
    res <- NULL
    for (i in 1:length(v)) {
        res <- rbind(res, optimize(function(x) 
          (ddvCopula(cbind(x, rep(v[i], length(x))),copula) - y[i])^2, 
            interval = c(0, 1))$minimum)
    }
    return(res)
}

setGeneric("invddvCopula")

###################
## Normal Copula ##
###################

## partial derivative d/du
##########################

dduNorm <- function(u, copula){
  rho <- copula@parameters

  u1 <- qnorm(u[,1]) # u ~ N(0,1)
  u2 <- qnorm(u[,2]) # v ~ N(0,1)

  return(pnorm(u2,mean=rho*u1,sd=sqrt(1-rho^2)))
}

setMethod("dduCopula", signature("numeric","normalCopula"),
          function(u, copula, ...) {
            dduNorm(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("dduCopula", signature("matrix","normalCopula"), dduNorm)

## inverse of the partial derivative d/du
#########################################

invdduNorm <- function(u, copula, y){
  rho <- copula@parameters
  return(pnorm(qnorm(y,mean=rho*qnorm(u),sd=sqrt(1-rho^2))))
}

setMethod("invdduCopula", signature("numeric","normalCopula","numeric"), invdduNorm)


## partial derivative d/dv
##########################

ddvNorm <- function(u, copula){
  rho <- copula@parameters

  u1 <- qnorm(u[,1])
  u2 <- qnorm(u[,2])

  return(pnorm(u1,mean=rho*u2,sd=sqrt(1-rho^2)))
}

setMethod("ddvCopula", signature("numeric","normalCopula"),
          function(u, copula, ...) {
            ddvNorm(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("ddvCopula", signature("matrix","normalCopula"), ddvNorm)

## inverse of the partial derivative d/dv
#########################################

invddvNorm <- function(v, copula, y){
  rho <- copula@parameters
  return(pnorm(qnorm(y,mean=rho*qnorm(v),sd=sqrt(1-rho^2))))
}

setMethod("invddvCopula", signature("numeric","normalCopula","numeric"), invddvNorm)

########################
## independent copula ##
########################

## partial derivative d/du
##########################

setMethod("dduCopula", signature("numeric","indepCopula"),
          function(u, copula, ...) {
            matrix(u,ncol=copula@dimension)[,2]
          })
setMethod("dduCopula", signature("matrix","indepCopula"), function(u, copula, ...) u[,2])

## inverse of the partial derivative d/du
#########################################

invdduIndep <- function(u, copula, y){
  return(y)
}

setMethod("invdduCopula", signature("numeric","indepCopula","numeric"), invdduIndep)

## partial derivative d/dv
##########################

setMethod("ddvCopula", signature("numeric","indepCopula"),
          function(u, copula, ...) {
            matrix(u,ncol=copula@dimension)[,1]
          })
setMethod("ddvCopula", signature("matrix","indepCopula"), function(u, copula, ...) u[,1])

## inverse of the partial derivative d/dv
#########################################

invddvIndep <- function(v, copula, y){
  return(y)
}

setMethod("invddvCopula", signature("numeric","indepCopula", "numeric"), invddvIndep)


####################
## Clayton Copula ##
####################

## partial derivative d/du
##########################

dduClayton <- function(u, copula){
  rho <- copula@parameters

  u1 <- u[,1]
  u2 <- u[,2]

  pmax(u1^(-rho)+u2^(-rho)-1,0)^((-1-rho)/rho)*u1^(-rho-1)
}

setMethod("dduCopula", signature("numeric","claytonCopula"),
          function(u, copula, ...) {
            dduClayton(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("dduCopula", signature("matrix","claytonCopula"), dduClayton)

## inverse of the partial derivative d/du
#########################################

invdduClayton <- function(u, copula, y){
    rho <- copula@parameters[1]
    if (length(u)!=length(y)) 
        stop("Length of u and y differ!")
    return(((y^(rho/(-1-rho))-1)*u^(-rho)+1)^(-1/rho)) # by DL
}

setMethod("invdduCopula", signature("numeric","claytonCopula","numeric"), invdduClayton)

## partial derivative d/dv
##########################

ddvClayton <- function(u, copula){
  rho <- copula@parameters
  if (!is.matrix(u)) u <- matrix(u, ncol=2)

  u1 <- u[,1]
  u2 <- u[,2]

  pmax(u2^(-rho)+u1^(-rho)-1,0)^((-1-rho)/rho)*u2^(-rho-1)
}

setMethod("ddvCopula", signature("numeric","claytonCopula"),
          function(u, copula, ...) {
            ddvClayton(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("ddvCopula", signature("matrix","claytonCopula"), ddvClayton)


## inverse of the partial derivative d/dv
#########################################

invddvClayton <- function(v, copula, y){
    rho <- copula@parameters[1]
    if (length(v)!=length(y)) 
        stop("Length of v and y differ!")
    return(((y^(rho/(-1-rho))-1)*v^(-rho)+1)^(-1/rho))
}

setMethod("invddvCopula", signature("numeric", "claytonCopula", "numeric"), invddvClayton)


###################
## Gumbel Copula ##
###################

## partial derivative d/du
##########################

dduGumbel <- function(u, copula){
  rho <- copula@parameters

  u1 <- u[,1]
  u2 <- u[,2]

  pcopula(gumbelCopula(rho),u) * ((-log(u1))^rho+(-log(u2))^rho)^(1/rho-1) * (-log(u1))^(rho-1)/u1
}

setMethod("dduCopula", signature("numeric","gumbelCopula"),
          function(u, copula, ...) {
            dduGumbel(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("dduCopula", signature("matrix","gumbelCopula"), dduGumbel)


## partial derivative d/dv
##########################

ddvGumbel <- function(u, copula){
  rho <- copula@parameters

  u1 <- u[,1]
  u2 <- u[,2]

  pcopula(gumbelCopula(rho),u) * ((-log(u2))^rho+(-log(u1))^rho)^(1/rho-1) * (-log(u2))^(rho-1)/u2
}

setMethod("ddvCopula", signature("numeric","gumbelCopula"),
          function(u, copula, ...) {
            ddvGumbel(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("ddvCopula", signature("matrix","gumbelCopula"), ddvGumbel)



##################
## Frank Copula ##
##################

## partial derivative d/du
##########################

dduFrank <- function(u, copula){
  rho <- copula@parameters

  u1 <- u[,1]
  u2 <- u[,2]

  exp(-rho*u1)*(exp(-rho*u2)-1) / ( (exp(-rho)-1) + (exp(-rho*u1)-1)*(exp(-rho*u2)-1) )
}

setMethod("dduCopula", signature("numeric","frankCopula"),
          function(u, copula, ...) {
            dduFrank(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("dduCopula", signature("matrix","frankCopula"), dduFrank)


## inverse of the partial derivative d/du
#########################################

invdduFrank <- function(u, copula, y){
    rho <- copula@parameters[1]
    if (length(u)!=length(y)) 
        stop("Length of u and y differ!")
    return( (-1/rho) * log( y*( exp(-rho)-1)/(exp(-rho*u)-y*(exp(-rho*u)-1)) +1) ) # by DL
}

setMethod("invdduCopula", signature("numeric", "frankCopula", "numeric"), invdduFrank)


## partial derivative d/dv
##########################

ddvFrank <- function(u, copula){
  rho <- copula@parameters

  u1 <- u[,1]
  u2 <- u[,2]

  exp(-rho*u2)*(exp(-rho*u1)-1) / ( (exp(-rho)-1) + (exp(-rho*u2)-1)*(exp(-rho*u1)-1) )
}

setMethod("ddvCopula", signature("numeric","frankCopula"),
          function(u, copula, ...) {
            ddvFrank(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("ddvCopula", signature("matrix","frankCopula"), ddvFrank)


## inverse of the partial derivative d/dv
#########################################

invddvFrank <- function(v, copula, y){
    rho <- copula@parameters[1]
    if (length(v)!=length(y)) 
        stop("Length of v and y differ!")
    return( (-1/rho) * log( y*( exp(-rho)-1)/(exp(-rho*v)-y*(exp(-rho*v)-1)) +1) )
}

setMethod("invddvCopula", signature("numeric", "frankCopula", "numeric"), invddvFrank)

####################
## student Copula ##
####################

## partial derivative d/du
##########################

dduStudent <- function(u, copula){
  df <- copula@df
  v <- qt(u,df=df)
  
  rho <- copula@parameters[1]
  
  return(pt(sqrt((df+1)/(df+v[,1]^2)) / sqrt(1 - rho^2) * (v[,2] - rho * v[,1]), df=df+1))
}

setMethod("dduCopula", signature("numeric","tCopula"),
          function(u, copula, ...) {
            dduStudent(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("dduCopula", signature("matrix","tCopula"), dduStudent)


## partial derivative d/dv
##########################

ddvStudent <- function(u, copula){
  df <- copula@df
  v <- qt(u, df=df)
  
  rho <- copula@parameters[1]
  
  return(pt(sqrt((df+1)/(df+v[,2]^2)) / sqrt(1 - rho^2) * (v[,1] - rho * v[,2]), df=df+1))
}

setMethod("ddvCopula", signature("numeric","tCopula"),
          function(u, copula, ...) {
            ddvStudent(matrix(u,ncol=copula@dimension),copula)
          })
setMethod("ddvCopula", signature("matrix","tCopula"), ddvStudent)


## kendall distribution

# empirical default
getKendallDistr <- function(copula, sample=NULL) {
  standardGeneric("getKendallDistr")
  if(is.null(sample)) sample <- rcopula(copula,1e6)
  empCop <- genEmpCop(sample)
  ken <- empCop(sample) # takes really long, any suggestions? Comparring a 1e6x3/1e6x2 matrix by 1e6 pairs/triplets values
  
  empKenFun <- function(tlevel) {
    res <- NULL
    for(t in tlevel) {
      res <- c(res,sum(ken<=t))
    }
    return(res/nrow(sample))
  }
  return(empKenFun)
}

setGeneric("getKendallDistr")

## 

kendallDistribution <- function(copula, t) {
  stop("There is no analytical expression implemented for this copula family. See 'getKendallDstr' for a numerical solution instead.")
}

setGeneric("kendallDistribution")

## Clayton
## kendall distribution/measure, taken from CDVine:::obs.stat
kendall.Clayton <- function(copula, t){
  par = copula@parameters
    
  kt <- rep(NA,length(t))
  kt <- t + t * (1 - t^par)/par
  kt[t==1] <- 1
  kt[t==0] <- 0
  return(kt)  
}

setMethod("kendallDistribution", signature("claytonCopula"), kendall.Clayton)

setMethod("getKendallDistr", signature("claytonCopula"), 
          function(copula) return(function(t) kendall.Clayton(copula, t)))

## Gumbel
## kendall distribution/measure, taken from CDVine:::obs.stat
kendall.Gumbel <- function(copula, t){
  par = copula@parameters
    
  kt <- rep(NA,length(t))
  kt <- t - t * log(t)/(par)
  kt[t==1] <- 1
  kt[t==0] <- 0
  return(kt)  
}

setMethod("kendallDistribution", signature("gumbelCopula"), kendall.Gumbel)

setMethod("getKendallDistr", signature("gumbelCopula"), 
          function(copula) return(function(t) kendall.Gumbel(copula, t)))

## Frank
## kendall distribution/measure, taken from CDVine:::obs.stat
kendall.Frank <- function(copula, t){
  par = copula@parameters
    
  kt <- rep(NA,length(t))
  kt <- t + log((1 - exp(-par))/(1 - exp(-par * t))) * (1 - exp(-par * t))/(par * exp(-par * t))
  kt[t==1] <- 1
  kt[t==0] <- 0
  return(kt)  
}

setMethod("kendallDistribution", signature("frankCopula"), kendall.Frank)

setMethod("getKendallDistr", signature("frankCopula"), 
          function(copula) return(function(t) kendall.Frank(copula, t)))

